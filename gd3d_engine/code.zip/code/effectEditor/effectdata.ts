class EffectElement extends gd3d.framework.transform
{
    public type: gd3d.framework.EffectElementTypeEnum = gd3d.framework.EffectElementTypeEnum.SingleMeshType;
    public beLoop: boolean = false;
    public name:string;
}